'use strict';

$(document).ready(function () {
    $('.skillbar').skillbar({
        speed: 1000
    });
});
