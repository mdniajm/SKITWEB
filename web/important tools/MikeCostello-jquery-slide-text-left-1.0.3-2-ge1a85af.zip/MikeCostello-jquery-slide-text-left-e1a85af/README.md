jquery-slide-text-left
======================

jQuery plugin for animating through an array of strings

[Demo](http://mikecostello.github.io/jquery-slide-text-left/)